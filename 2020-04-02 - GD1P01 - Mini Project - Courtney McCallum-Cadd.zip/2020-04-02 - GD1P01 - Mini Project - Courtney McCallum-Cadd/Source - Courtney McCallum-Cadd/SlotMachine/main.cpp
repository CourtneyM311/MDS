#include <iostream>
#include <cstdlib>
#include <ctime>
#include <windows.h>
#include <math.h>

using namespace std;

enum EColour
{
	COLOUR_WHITE_ON_BLACK = 0,			// White on Black - default colour
	COLOUR_YELLOW_ON_BLACK = 1,			// Yellow on Black.
};

HANDLE out = GetStdHandle(STD_OUTPUT_HANDLE);

void ClearScreen();				//Function to Clear the Console Window.
void SetColour(EColour colour);	//Function to set the colour of text.


int Bal = 2000;			//Global Variable: Starting Balance is 2000, can be used anywhere in code.
int Bid = 0;			//Global variable: So Bid can be used anywhere in code.


int main()
{
	int mSelect = 0;	//(m)enu Select: inputs on menu.

	rmenu:

	ClearScreen();

	srand((unsigned int)time(0));		//To generate the random numbers

	SetColour(COLOUR_YELLOW_ON_BLACK);

	std::cout << R"(
  =========================================================================
	 __  _         _                          _      _              
	/ _\| |  ___  | |_    /\/\    __ _   ___ | |__  (_) _ __    ___ 
	\ \ | | / _ \ | __|  /    \  / _` | / __|| '_ \ | || '_ \  / _ \
	_\ \| || (_) || |_  / /\/\ \| (_| || (__ | | | || || | | ||  __/
	\__/|_| \___/  \__| \/    \/ \__,_| \___||_| |_||_||_| |_| \___|

  =========================================================================
	)" << endl << endl;

	//Main Menu

	cout << "				------$$-----" << endl;

	cout << endl << endl;
	
	cout << "			    1) Play Slot Machine" << endl;
	cout << "			    2) Credits" << endl;
	cout << "			    3) Quit Slot Machine" << endl;

	cout << endl << endl;

	cout << "				------$$-----" << endl;

	cin >> mSelect;		//Player's input for menu.

	if (mSelect == 1)		//To play the slots
	{
		ClearScreen();

		std::cout << R"(
  =========================================================================
	 __  _         _                          _      _              
	/ _\| |  ___  | |_    /\/\    __ _   ___ | |__  (_) _ __    ___ 
	\ \ | | / _ \ | __|  /    \  / _` | / __|| '_ \ | || '_ \  / _ \
	_\ \| || (_) || |_  / /\/\ \| (_| || (__ | | | || || | | ||  __/
	\__/|_| \___/  \__| \/    \/ \__,_| \___||_| |_||_||_| |_| \___|

  =========================================================================
	)" << endl << endl;

		while (Bal != 0)
		{
		rplay:

			ClearScreen();

			std::cout << R"(
  =========================================================================
	 __  _         _                          _      _              
	/ _\| |  ___  | |_    /\/\    __ _   ___ | |__  (_) _ __    ___ 
	\ \ | | / _ \ | __|  /    \  / _` | / __|| '_ \ | || '_ \  / _ \
	_\ \| || (_) || |_  / /\/\ \| (_| || (__ | | | || || | | ||  __/
	\__/|_| \___/  \__| \/    \/ \__,_| \___||_| |_||_||_| |_| \___|

  =========================================================================
	)" << endl << endl;

			cout << "			  Remaining Balance: $" << Bal << endl;
			cout << endl;

			cout << "			    Place Your Bid: $"; cin >> Bid;
			cout << endl << endl;

			cout << "				------$$-----" << endl;

			cout << endl << endl;

			if (Bid > Bal || Bid == 0)
			{
				cout << endl << endl << endl;

				cout << "			        Invalid Bid." << endl;
				cout << endl;
				cout << "		              Please Try Again" << endl;

				cout << endl << endl;

				cout << "				------$$-----" << endl;

				cout << endl << endl;

				system("Pause");

				goto rplay;
			}

			if (Bid <= Bal)
			{
				//To create the random numbers.
				signed int slot1 = rand() % 6 + 2;
				signed int slot2 = rand() % 6 + 2;
				signed int slot3 = rand() % 6 + 2;

				Bal = Bal - Bid;

				cout << "		  ======================================== " << endl;
				cout << "		   00000000000000000000000000000000000000  " << endl;
				cout << "		   0 ================================== 0  " << endl;
				cout << "		   0 |          |          |          | 0  " << endl;
				cout << "		   0 |          |          |          | 0  " << endl;
				cout << "                   0 |     " << slot1 << "    |     " << slot2 << "    |     " << slot3 << "    | 0  " << endl;
				cout << "		   0 |          |          |          | 0  " << endl;
				cout << "		   0 |          |          |          | 0  " << endl;
				cout << "		   0 ================================== 0  " << endl;
				cout << "	           00000000000000000000000000000000000000  " << endl;
				cout << "		  ======================================== " << endl;

				cout << endl << endl;

				int wonamnt;	//Amount won.

				if (slot1 == slot2 && slot2 == slot3 && slot3 == 7)			//Jacpot = triple 7
				{
					wonamnt = Bid * 10;

					cout << "					     $$$ JACKPOT $$$" << endl;
					cout << endl;

					cout << "					     You Won: $" << wonamnt << endl;
					cout << endl;
					cout << "				------$$-----" << endl;

					Bal = wonamnt + Bal;
				}

				else if (slot1 == slot2 && slot2 == slot3 && slot3 != 7)		//Any number, except 7, tripled
				{
					wonamnt = Bid * 5;

					cout << "				   Winner!!" << endl;
					cout << endl;

					cout << "			       You Won: $" << wonamnt << endl;
					cout << endl;
					cout << "				------$$-----" << endl;

					Bal = wonamnt + Bal;
				}

				else if (slot1 == slot2 || slot2 == slot3 || slot3 == slot1)		//Any doubled number
				{
					wonamnt = Bid * 3;

					cout << "				   Winner!!" << endl;
					cout << endl;

					cout << "			       You Won: $" << wonamnt << endl;
					cout << endl;
					cout << "				------$$-----" << endl;

					Bal = wonamnt + Bal;
				}

				else
				{
					wonamnt = 0;		//No matching numbers

					cout << "				   Oh No!" << endl;
					cout << endl;

					cout << "			      You Lost:  $" << Bid << endl;

					cout << endl;
					cout << "				------$$-----" << endl;

				}

				cout << endl << endl;

				system("Pause");
			}

		}

		if (Bal == 0)
		{

			ClearScreen();

			std::cout << R"(
  =========================================================================
	 __  _         _                          _      _              
	/ _\| |  ___  | |_    /\/\    __ _   ___ | |__  (_) _ __    ___ 
	\ \ | | / _ \ | __|  /    \  / _` | / __|| '_ \ | || '_ \  / _ \
	_\ \| || (_) || |_  / /\/\ \| (_| || (__ | | | || || | | ||  __/
	\__/|_| \___/  \__| \/    \/ \__,_| \___||_| |_||_||_| |_| \___|
  =========================================================================
	)" << endl << endl;

			cout << endl << endl << endl;

			cout << "		                GAME OVER!" << endl;
			cout << endl;

			cout << "			   Thanks for Playing." << endl;

			cout << endl << endl;

			cout << "		              ------$$-----" << endl;

			cout << endl << endl << endl << endl << endl;

			system("Pause");

			goto rmenu; 
		}

	}

	if (mSelect == 2)		//To view the Credits.
	{
		ClearScreen();

		std::cout << R"(
  =========================================================================
	 __  _         _                          _      _              
	/ _\| |  ___  | |_    /\/\    __ _   ___ | |__  (_) _ __    ___ 
	\ \ | | / _ \ | __|  /    \  / _` | / __|| '_ \ | || '_ \  / _ \
	_\ \| || (_) || |_  / /\/\ \| (_| || (__ | | | || || | | ||  __/
	\__/|_| \___/  \__| \/    \/ \__,_| \___||_| |_||_||_| |_| \___|
  =========================================================================
	)" << endl << endl;

		cout << "				---CREDITS---" << endl;
		cout << endl;

		cout << "			         Created By" << endl;
		cout << "			   Courtney McCallum-Cadd" << endl;

		cout << endl;

		cout << "			          BSE20021" << endl;
		cout << "		    Introduction to Software Engineering" << endl;

		cout << endl;

		cout << "				------$$-----" << endl;

		cout << endl << endl;

		system("Pause");

		goto rmenu;
	}

	if (mSelect == 3)		//To quit the game.
	{
		std::cout << R"(
  =========================================================================
	 __  _         _                          _      _              
	/ _\| |  ___  | |_    /\/\    __ _   ___ | |__  (_) _ __    ___ 
	\ \ | | / _ \ | __|  /    \  / _` | / __|| '_ \ | || '_ \  / _ \
	_\ \| || (_) || |_  / /\/\ \| (_| || (__ | | | || || | | ||  __/
	\__/|_| \___/  \__| \/    \/ \__,_| \___||_| |_||_||_| |_| \___|
  =========================================================================
	)" << endl << endl << endl << endl;

		cout << "				------$$-----" << endl;

		cout << endl << endl;

		cout << "			      Thanks for Playing!" << endl << endl;

		cout << endl;

		cout << "				------$$-----" << endl;

		cout << endl << endl << endl;

		return (0);
	}

	else (mSelect < 1 || mSelect >= 4);
	{
		cout << "			 Error: Not a Valid Input" << endl;

		cout << endl << endl;

		cout << "				------$$-----" << endl;

		system("Pause");

		goto rmenu;
	}


	return (0);
}

void ClearScreen()
{
	COORD coordScreen = { 0, 0 };
	DWORD cCharsWritten;
	CONSOLE_SCREEN_BUFFER_INFO csbi;
	DWORD dwConSize;
	HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);

	GetConsoleScreenBufferInfo(hConsole, &csbi);
	dwConSize = csbi.dwSize.X * csbi.dwSize.Y;

	FillConsoleOutputCharacter(hConsole, TEXT(' '), dwConSize, coordScreen, &cCharsWritten);
	GetConsoleScreenBufferInfo(hConsole, &csbi);
	FillConsoleOutputAttribute(hConsole, csbi.wAttributes, dwConSize, coordScreen, &cCharsWritten);
	SetConsoleCursorPosition(hConsole, coordScreen);
}

void SetColour(EColour colour)
{
	switch (colour)
	{
	case COLOUR_WHITE_ON_BLACK:		 // White on Black.
		SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), FOREGROUND_INTENSITY | FOREGROUND_RED | FOREGROUND_GREEN |
			FOREGROUND_BLUE);
		break;

	case COLOUR_YELLOW_ON_BLACK:		 // Yellow on Black.
		SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), FOREGROUND_INTENSITY | FOREGROUND_RED | FOREGROUND_GREEN);
		break;
	}
}

